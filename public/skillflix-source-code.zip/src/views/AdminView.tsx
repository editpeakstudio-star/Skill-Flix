import React, { useState } from 'react';
import { 
  TrendingUp, 
  PlayCircle, 
  FileText, 
  Layers, 
  Users, 
  CreditCard, 
  Settings, 
  ArrowLeft, 
  LogOut, 
  Plus, 
  Search, 
  Check, 
  X, 
  Edit2, 
  Trash2, 
  CheckCircle, 
  Lock, 
  Sparkles, 
  Power, 
  Tag, 
  ShieldCheck, 
  Calendar,
  Image as ImageIcon,
  Crown,
  Shield,
  Zap,
  PlaySquare,
  Folder as FolderIcon,
  FolderPlus,
  FolderOpen,
  ChevronRight,
  ChevronDown,
  History,
  AlertTriangle,
  UserCheck,
  UserX,
  Move,
  KeyRound,
  Eye,
  SlidersHorizontal
} from 'lucide-react';
import { 
  UserProfile, 
  Category, 
  Folder,
  VideoLesson, 
  PdfResource, 
  PaymentRequest, 
  PlatformSettings, 
  SalesRecord,
  AuditLog,
  PredefinedRole,
  PermissionKey,
  SYSTEM_PERMISSIONS
} from '../types';
import { 
  MASTER_ADMIN_EMAIL,
  isProtectedOwner,
  hasPermission,
  getPermissionsForRole,
  saveCategory, 
  toggleCategoryStatus, 
  deleteCategory,
  saveFolder,
  deleteFolder,
  moveFolder,
  saveVideo, 
  toggleVideoPublish, 
  deleteVideo,
  savePdf, 
  togglePdfPublish, 
  deletePdf,
  updateAdminRoleAndPermissions,
  toggleAdminSuspension,
  removeAdminPrivileges,
  updateUserAllAccess, 
  updateUserCategoryAccess, 
  setAllCategoriesAccess,
  resolvePaymentRequest, 
  updateSettings,
  logoutUser,
  recordAuditLog
} from '../services/firebase';
import { useToast } from '../components/Toast';

interface AdminViewProps {
  currentUser: UserProfile | null;
  categories: Category[];
  folders: Folder[];
  videos: VideoLesson[];
  pdfs: PdfResource[];
  users: UserProfile[];
  paymentRequests: PaymentRequest[];
  settings: PlatformSettings;
  sales: SalesRecord[];
  auditLogs: AuditLog[];
  onNavigate: (view: string) => void;
  onSeedDefaults: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  currentUser,
  categories,
  folders,
  videos,
  pdfs,
  users,
  paymentRequests,
  settings,
  sales,
  auditLogs,
  onNavigate,
  onSeedDefaults
}) => {
  const { showToast } = useToast();
  
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<
    'analytics' | 'folders' | 'videos' | 'pdfs' | 'categories' | 'users' | 'roles' | 'audit' | 'payments' | 'payment-settings' | 'general'
  >('folders');

  // Operation locks per item ID
  const [operatingIds, setOperatingIds] = useState<Record<string, boolean>>({});

  // Modals for CRUD
  const [editingFolder, setEditingFolder] = useState<Partial<Folder> | null>(null);
  const [folderToDelete, setFolderToDelete] = useState<Folder | null>(null);
  const [deleteFolderContents, setDeleteFolderContents] = useState(true);

  const [editingVideo, setEditingVideo] = useState<Partial<VideoLesson> | null>(null);
  const [editingPdf, setEditingPdf] = useState<Partial<PdfResource> | null>(null);
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);
  const [viewingProof, setViewingProof] = useState<PaymentRequest | null>(null);
  const [rejectNote, setRejectNote] = useState('');

  // Role & Permissions Modal
  const [selectedUserForRole, setSelectedUserForRole] = useState<UserProfile | null>(null);
  const [selectedRoleType, setSelectedRoleType] = useState<PredefinedRole>('admin');
  const [customPermissions, setCustomPermissions] = useState<PermissionKey[]>([]);

  // Folder Browser Active State
  const [activeBrowserFolderId, setActiveBrowserFolderId] = useState<string | null>(null);

  // Search & Filters
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'owner' | 'master' | 'admin' | 'student'>('all');
  const [auditSearch, setAuditSearch] = useState('');
  const [videoSearch, setVideoSearch] = useState('');
  const [pdfSearch, setPdfSearch] = useState('');
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});

  // Settings form
  const [settingsForm, setSettingsForm] = useState<PlatformSettings>(settings);
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  // Check authorization & status
  const isOwner = isProtectedOwner(currentUser);
  const isMasterAdmin = isOwner || currentUser?.role === 'master_admin';
  const isSuspended = currentUser?.isSuspended;

  // Granular permissions check for UI display
  const canViewAnalytics = hasPermission(currentUser, 'analytics.view') || hasPermission(currentUser, 'dashboard.view');
  const canManageFolders = hasPermission(currentUser, 'folders.create') || hasPermission(currentUser, 'folders.edit') || hasPermission(currentUser, 'folders.delete');
  const canManageVideos = hasPermission(currentUser, 'videos.create') || hasPermission(currentUser, 'videos.edit') || hasPermission(currentUser, 'videos.delete');
  const canManagePdfs = hasPermission(currentUser, 'pdfs.create') || hasPermission(currentUser, 'pdfs.edit') || hasPermission(currentUser, 'pdfs.delete');
  const canManageStudents = hasPermission(currentUser, 'students.manage');
  const canManageAdmins = isOwner || hasPermission(currentUser, 'admins.manage');
  const canViewAudit = isOwner || hasPermission(currentUser, 'audit.view');
  const canVerifyPayments = hasPermission(currentUser, 'payments.verify');
  const canManageSettings = isOwner || hasPermission(currentUser, 'settings.manage');

  if (isSuspended) {
    return (
      <div className="p-8 rounded-2xl bg-[#090D16] border border-rose-500/30 text-center max-w-md mx-auto my-12 text-zinc-100">
        <AlertTriangle className="w-12 h-12 text-rose-400 mx-auto mb-3" />
        <h2 className="text-base font-bold text-white mb-2">Account Suspended</h2>
        <p className="text-xs text-zinc-400 mb-5">
          Your administrative privileges have been temporarily suspended by the platform administrator.
        </p>
        <button
          onClick={() => onNavigate('home')}
          className="px-6 py-2 rounded-xl bg-zinc-800 text-white text-xs font-semibold cursor-pointer"
        >
          Return to Learning Hub
        </button>
      </div>
    );
  }

  if (!currentUser || (currentUser.role === 'user' && !isOwner)) {
    return (
      <div className="p-8 rounded-2xl bg-[#090D16] border border-red-500/30 text-center max-w-md mx-auto my-12 text-zinc-100">
        <Shield className="w-12 h-12 text-rose-400 mx-auto mb-3" />
        <h2 className="text-base font-bold text-white mb-2">Access Restricted</h2>
        <p className="text-xs text-zinc-400 mb-5">
          Your account does not have administrator privileges.
        </p>
        <button
          onClick={() => onNavigate('home')}
          className="px-6 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold text-xs shadow-md cursor-pointer"
        >
          Return to Learning Hub
        </button>
      </div>
    );
  }

  const setOperating = (id: string, busy: boolean) => {
    setOperatingIds(prev => ({ ...prev, [id]: busy }));
  };

  // ==========================================================
  // FOLDER MANAGEMENT HANDLERS
  // ==========================================================
  const handleSaveFolderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFolder?.name?.trim()) {
      showToast('Please enter a folder name.', 'error');
      return;
    }

    try {
      const saved = await saveFolder({
        ...editingFolder,
        name: editingFolder.name.trim()
      });
      showToast(`Folder "${saved.name}" saved successfully!`, 'success');
      setEditingFolder(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to save folder.', 'error');
    }
  };

  const handleConfirmDeleteFolder = async () => {
    if (!folderToDelete) return;
    try {
      const result = await deleteFolder(folderToDelete.id, deleteFolderContents);
      showToast(`Folder deleted (${result.deletedSubfolders} subfolders, ${result.deletedVideos} videos removed).`, 'info');
      setFolderToDelete(null);
      if (activeBrowserFolderId === folderToDelete.id) {
        setActiveBrowserFolderId(null);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete folder.', 'error');
    }
  };

  // Breadcrumbs for admin folder browser
  const getAdminBreadcrumbs = () => {
    if (!activeBrowserFolderId) return [];
    const crumbs: { id: string | null; name: string }[] = [{ id: null, name: 'Root Library' }];
    let cur = folders.find(f => f.id === activeBrowserFolderId);
    const path: { id: string; name: string }[] = [];
    while (cur) {
      path.unshift({ id: cur.id, name: cur.name });
      cur = cur.parentId ? folders.find(f => f.id === cur!.parentId) : undefined;
    }
    return [...crumbs, ...path];
  };

  // ==========================================================
  // ROLES & PERMISSIONS MANAGEMENT HANDLERS
  // ==========================================================
  const handleOpenRoleModal = (user: UserProfile) => {
    setSelectedUserForRole(user);
    const roleType: PredefinedRole = user.predefinedRole || (user.role === 'master_admin' ? 'master_admin' : 'admin');
    setSelectedRoleType(roleType);
    setCustomPermissions(user.permissions || getPermissionsForRole(roleType));
  };

  const handleSaveRoleAndPermissions = async () => {
    if (!selectedUserForRole || !currentUser) return;

    try {
      const assignedRole: 'master_admin' | 'admin' = selectedRoleType === 'master_admin' ? 'master_admin' : 'admin';
      const permsToSave = selectedRoleType === 'custom' ? customPermissions : getPermissionsForRole(selectedRoleType);

      await updateAdminRoleAndPermissions(
        currentUser,
        selectedUserForRole.uid,
        assignedRole,
        selectedRoleType,
        permsToSave
      );

      showToast(`Updated permissions & role for ${selectedUserForRole.displayName}!`, 'success');
      setSelectedUserForRole(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to update admin role.', 'error');
    }
  };

  const handleToggleSuspension = async (user: UserProfile) => {
    if (!currentUser) return;
    const nextState = !user.isSuspended;
    try {
      await toggleAdminSuspension(currentUser, user.uid, nextState);
      showToast(nextState ? `Suspended administrative access for ${user.displayName}` : `Reactivated access for ${user.displayName}`, 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle suspension.', 'error');
    }
  };

  const handleRemoveAdmin = async (user: UserProfile) => {
    if (!currentUser) return;
    if (!confirm(`Are you sure you want to revoke all admin privileges from ${user.displayName}?`)) return;

    try {
      await removeAdminPrivileges(currentUser, user.uid);
      showToast(`Revoked admin privileges from ${user.displayName}.`, 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to revoke admin privileges.', 'error');
    }
  };

  const handleToggleUserAllAccess = async (user: UserProfile) => {
    if (operatingIds[user.uid]) return;
    const targetState = !user.hasAllAccess;
    setOperating(user.uid, true);

    try {
      await updateUserAllAccess(user.uid, targetState);
      showToast(targetState ? `Turned ON All-Access for ${user.displayName}` : `Turned OFF All-Access for ${user.displayName}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update All-Access status.', 'error');
    } finally {
      setOperating(user.uid, false);
    }
  };

  // Video toggle
  const handleToggleVideo = async (video: VideoLesson) => {
    if (operatingIds[video.id]) return;
    const targetState = !video.isPublished;
    setOperating(video.id, true);

    try {
      await toggleVideoPublish(video.id, targetState);
      showToast(targetState ? 'Published video' : 'Unpublished video', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle video.', 'error');
    } finally {
      setOperating(video.id, false);
    }
  };

  // Video Save Submit
  const handleSaveVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVideo?.title?.trim() || !editingVideo?.categoryId) {
      showToast('Title and Category are required.', 'error');
      return;
    }

    try {
      await saveVideo(editingVideo as any);
      showToast('Video lesson saved successfully!', 'success');
      setEditingVideo(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to save video.', 'error');
    }
  };

  // PDF Save Submit
  const handleSavePdfSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPdf?.title?.trim() || !editingPdf?.categoryId) {
      showToast('Title and Category are required.', 'error');
      return;
    }

    try {
      await savePdf(editingPdf as any);
      showToast('PDF guide saved successfully!', 'success');
      setEditingPdf(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to save PDF.', 'error');
    }
  };

  // Payment Resolution
  const handleResolvePayment = async (requestId: string, status: 'approved' | 'rejected') => {
    try {
      await resolvePaymentRequest(requestId, status, rejectNote, currentUser);
      showToast(status === 'approved' ? 'Payment approved & courses unlocked!' : 'Payment rejected.', 'success');
      setViewingProof(null);
      setRejectNote('');
    } catch (err: any) {
      showToast(err.message || 'Failed to resolve payment.', 'error');
    }
  };

  // Platform Settings Save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSavingSettings(true);
      await updateSettings(settingsForm, currentUser);
      showToast('Platform settings saved successfully!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save platform settings.', 'error');
    } finally {
      setIsSavingSettings(false);
    }
  };

  // Filtered lists
  const filteredVideos = videos.filter(v => {
    if (!videoSearch) return true;
    const q = videoSearch.toLowerCase();
    return v.title.toLowerCase().includes(q) || v.categoryName.toLowerCase().includes(q) || (v.folderName && v.folderName.toLowerCase().includes(q));
  });

  const filteredPdfs = pdfs.filter(p => {
    if (!pdfSearch) return true;
    const q = pdfSearch.toLowerCase();
    return p.title.toLowerCase().includes(q) || p.categoryName.toLowerCase().includes(q);
  });

  const filteredUsers = users.filter(u => {
    if (userRoleFilter === 'owner' && !isProtectedOwner(u)) return false;
    if (userRoleFilter === 'master' && u.role !== 'master_admin') return false;
    if (userRoleFilter === 'admin' && (u.role !== 'admin' || isProtectedOwner(u))) return false;
    if (userRoleFilter === 'student' && u.role !== 'user') return false;
    if (userSearch) {
      const q = userSearch.toLowerCase();
      return u.email.toLowerCase().includes(q) || u.displayName.toLowerCase().includes(q) || (u.phoneNumber && u.phoneNumber.includes(q));
    }
    return true;
  });

  const filteredAuditLogs = auditLogs.filter(l => {
    if (!auditSearch) return true;
    const q = auditSearch.toLowerCase();
    return l.actorEmail.toLowerCase().includes(q) || l.action.toLowerCase().includes(q) || (l.targetEmail && l.targetEmail.toLowerCase().includes(q)) || l.details.toLowerCase().includes(q);
  });

  // Calculate stats
  const totalRevenue = sales.reduce((acc, s) => acc + (s.amount || 0), 0);
  const pendingPaymentsCount = paymentRequests.filter(p => p.status === 'pending').length;

  return (
    <div className="flex flex-col lg:flex-row min-h-[85vh] bg-[#05070D] rounded-2xl sm:rounded-3xl border border-blue-500/15 overflow-hidden shadow-2xl">
      
      {/* ======================================================== */}
      {/* SIDEBAR NAVIGATION (Matching Screenshot 4)               */}
      {/* ======================================================== */}
      <aside className="w-full lg:w-64 bg-[#090D16] border-b lg:border-b-0 lg:border-r border-blue-500/15 flex flex-col justify-between p-4 shrink-0">
        <div className="space-y-4">
          
          {/* Admin Identity Header */}
          <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-[#05070D] border border-blue-500/20">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 p-1.5 flex items-center justify-center text-black shadow-md shadow-yellow-500/30 shrink-0">
              <Crown className="w-5 h-5 fill-black text-black" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white tracking-tight">Admin Console</span>
                <span className={`text-[8px] font-extrabold uppercase px-1.5 py-0.2 rounded ${
                  isOwner 
                    ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40' 
                    : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                }`}>
                  {isOwner ? 'OWNER' : (currentUser?.assignedRoleTitle || currentUser?.role?.toUpperCase())}
                </span>
              </div>
              <span className="text-[10px] text-zinc-400 font-mono truncate block mt-0.5">
                {currentUser?.email}
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1 text-xs">
            {canViewAnalytics && (
              <button
                type="button"
                onClick={() => setActiveTab('analytics')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'analytics'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <TrendingUp className="w-4 h-4" />
                  <span>Financial Analytics</span>
                </div>
                <span className="text-[10px] font-mono text-zinc-400">₹{totalRevenue}</span>
              </button>
            )}

            {canManageFolders && (
              <button
                type="button"
                onClick={() => setActiveTab('folders')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'folders'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FolderOpen className="w-4 h-4" />
                  <span>Folder Library</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 font-mono text-zinc-400">{folders.length}</span>
              </button>
            )}

            {canManageVideos && (
              <button
                type="button"
                onClick={() => setActiveTab('videos')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'videos'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <PlaySquare className="w-4 h-4" />
                  <span>Video Manager</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 font-mono text-zinc-400">{videos.length}</span>
              </button>
            )}

            {canManagePdfs && (
              <button
                type="button"
                onClick={() => setActiveTab('pdfs')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'pdfs'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FileText className="w-4 h-4" />
                  <span>PDF Publications</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 font-mono text-zinc-400">{pdfs.length}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveTab('categories')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                activeTab === 'categories'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Layers className="w-4 h-4" />
                <span>Course Suites</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 font-mono text-zinc-400">{categories.length}</span>
            </button>

            {canManageStudents && (
              <button
                type="button"
                onClick={() => setActiveTab('users')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'users'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Users className="w-4 h-4" />
                  <span>Student Access</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 font-mono text-zinc-400">{users.length}</span>
              </button>
            )}

            {canManageAdmins && (
              <button
                type="button"
                onClick={() => setActiveTab('roles')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'roles'
                    ? 'bg-amber-500 text-black shadow-md shadow-amber-500/30 font-bold'
                    : 'text-amber-400/90 hover:text-amber-300 hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Roles & Permissions</span>
                </div>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-950/80 text-amber-300 font-bold">SECURE</span>
              </button>
            )}

            {canViewAudit && (
              <button
                type="button"
                onClick={() => setActiveTab('audit')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'audit'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <History className="w-4 h-4" />
                  <span>Security Audit Logs</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 font-mono text-zinc-400">{auditLogs.length}</span>
              </button>
            )}

            {canVerifyPayments && (
              <button
                type="button"
                onClick={() => setActiveTab('payments')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'payments'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <CreditCard className="w-4 h-4" />
                  <span>Payment Proofs</span>
                </div>
                {pendingPaymentsCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-500 text-black animate-pulse">
                    {pendingPaymentsCount}
                  </span>
                )}
              </button>
            )}

            {canManageSettings && (
              <button
                type="button"
                onClick={() => setActiveTab('payment-settings')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                  activeTab === 'payment-settings'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Settings className="w-4 h-4" />
                  <span>Payment Gateway</span>
                </div>
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveTab('general')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold transition-all cursor-pointer ${
                activeTab === 'general'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <SlidersHorizontal className="w-4 h-4" />
                <span>General Settings</span>
              </div>
            </button>
          </nav>
        </div>

        {/* Footer Navigation Back Button */}
        <div className="pt-4 border-t border-zinc-800/80">
          <button
            onClick={() => onNavigate('home')}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Learning Hub</span>
          </button>
        </div>
      </aside>

      {/* ======================================================== */}
      {/* MAIN CONTENT WORKSPACE                                   */}
      {/* ======================================================== */}
      <main className="flex-1 p-4 sm:p-6 overflow-y-auto">
        
        {/* ======================================================== */}
        {/* TAB 1: FINANCIAL ANALYTICS                               */}
        {/* ======================================================== */}
        {activeTab === 'analytics' && canViewAnalytics && (
          <div className="space-y-5 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white">Financial & Sales Analytics</h2>
                <p className="text-xs text-zinc-400">Real-time revenue monitoring and transactions registry.</p>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-[#090D16] border border-blue-500/20">
                <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">Total Sales</span>
                <p className="text-xl font-extrabold text-amber-400 font-mono mt-1">₹{totalRevenue}</p>
              </div>
              <div className="p-4 rounded-2xl bg-[#090D16] border border-blue-500/20">
                <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">Transactions</span>
                <p className="text-xl font-extrabold text-white font-mono mt-1">{sales.length}</p>
              </div>
              <div className="p-4 rounded-2xl bg-[#090D16] border border-blue-500/20">
                <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">Active Students</span>
                <p className="text-xl font-extrabold text-cyan-400 font-mono mt-1">{users.length}</p>
              </div>
              <div className="p-4 rounded-2xl bg-[#090D16] border border-blue-500/20">
                <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">Pending Proofs</span>
                <p className="text-xl font-extrabold text-rose-400 font-mono mt-1">{pendingPaymentsCount}</p>
              </div>
            </div>

            {/* Sales Table */}
            <div className="rounded-2xl bg-[#090D16] border border-blue-500/20 overflow-hidden">
              <div className="p-3.5 border-b border-zinc-800 flex items-center justify-between">
                <span className="text-xs font-bold text-white uppercase tracking-wider">Recent Sales History</span>
              </div>
              {sales.length > 0 ? (
                <div className="divide-y divide-zinc-800/80">
                  {sales.map((sale) => (
                    <div key={sale.id} className="p-3 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white">{sale.planType}</span>
                        <span className="text-[10px] text-zinc-400 font-mono block">{sale.userEmail}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-amber-400">₹{sale.amount}</span>
                        <span className="text-[10px] text-zinc-500 block">{new Date(sale.date).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-zinc-500 text-xs">No sales recorded yet.</div>
              )}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: DYNAMIC FOLDERS & SUBFOLDERS HIERARCHY            */}
        {/* ======================================================== */}
        {activeTab === 'folders' && canManageFolders && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <FolderOpen className="w-5 h-5 text-cyan-400" />
                  <span>Dynamic Folder Library</span>
                </h2>
                <p className="text-xs text-zinc-400">
                  Organize courses into nested subfolders, videos, and study materials with breadcrumbs.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingFolder({
                    parentId: activeBrowserFolderId || null,
                    categoryId: activeBrowserFolderId ? folders.find(f => f.id === activeBrowserFolderId)?.categoryId : undefined
                  })}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  <FolderPlus className="w-4 h-4" />
                  <span>{activeBrowserFolderId ? '+ New Subfolder' : '+ New Root Folder'}</span>
                </button>
              </div>
            </div>

            {/* Folder Browser Breadcrumbs */}
            {activeBrowserFolderId && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-[#090D16] border border-blue-500/20 text-xs text-zinc-300">
                {getAdminBreadcrumbs().map((crumb, idx, arr) => (
                  <React.Fragment key={crumb.id || 'root'}>
                    {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-zinc-600" />}
                    <button
                      type="button"
                      onClick={() => setActiveBrowserFolderId(crumb.id)}
                      className={`cursor-pointer transition-colors ${
                        idx === arr.length - 1 ? 'text-cyan-400 font-bold' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      {crumb.name}
                    </button>
                  </React.Fragment>
                ))}
              </div>
            )}

            {/* Subfolders Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {folders
                .filter(f => activeBrowserFolderId ? f.parentId === activeBrowserFolderId : (!f.parentId || categories.some(c => c.id === f.parentId)))
                .map((folder) => {
                  const subCount = folders.filter(sf => sf.parentId === folder.id).length;
                  const vCount = videos.filter(v => v.folderId === folder.id).length;
                  const pCount = pdfs.filter(p => p.folderId === folder.id).length;

                  return (
                    <div
                      key={folder.id}
                      className="p-3.5 rounded-2xl bg-[#090D16] border border-blue-500/20 hover:border-cyan-400/40 transition-all flex flex-col justify-between group"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div 
                            onClick={() => setActiveBrowserFolderId(folder.id)}
                            className="flex items-center gap-2 cursor-pointer flex-1 min-w-0"
                          >
                            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-cyan-400 flex items-center justify-center shrink-0">
                              <FolderIcon className="w-4 h-4 text-cyan-400" />
                            </div>
                            <span className="font-bold text-white text-xs truncate group-hover:text-cyan-300 transition-colors">
                              {folder.name}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => setEditingFolder(folder)}
                              className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-800 cursor-pointer"
                              title="Edit Folder"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setFolderToDelete(folder)}
                              className="p-1 rounded text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 cursor-pointer"
                              title="Delete Folder"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {folder.description && (
                          <p className="text-[11px] text-zinc-400 line-clamp-2 mb-3">
                            {folder.description}
                          </p>
                        )}
                      </div>

                      <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-[10px] text-zinc-400">
                        <span>{subCount} Subfolders • {vCount} Videos • {pCount} PDFs</span>
                        <button
                          type="button"
                          onClick={() => setActiveBrowserFolderId(folder.id)}
                          className="text-cyan-400 font-bold hover:underline cursor-pointer"
                        >
                          Open Folder →
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>

            {/* Empty State */}
            {folders.filter(f => activeBrowserFolderId ? f.parentId === activeBrowserFolderId : (!f.parentId || categories.some(c => c.id === f.parentId))).length === 0 && (
              <div className="p-8 rounded-2xl bg-[#090D16] border border-zinc-800 text-center">
                <FolderIcon className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
                <h4 className="text-xs font-bold text-white">No subfolders inside this level</h4>
                <p className="text-[11px] text-zinc-400 mt-1">
                  Click "+ New Subfolder" above or seed default course suites.
                </p>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: VIDEO MANAGEMENT (Matching Screenshot 3)           */}
        {/* ======================================================== */}
        {activeTab === 'videos' && canManageVideos && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white">Video Lesson Management</h2>
                <p className="text-xs text-zinc-400">Upload lessons, configure preview locks, and toggle publish status.</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingVideo({
                    categoryId: categories[0]?.id || '',
                    categoryName: categories[0]?.name || '',
                    folderId: activeBrowserFolderId || categories[0]?.id,
                    isPublished: true,
                    isFreePreview: false
                  })}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Add Video Lesson</span>
                </button>
              </div>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-500" />
              <input
                type="text"
                value={videoSearch}
                onChange={e => setVideoSearch(e.target.value)}
                placeholder="Search videos by title or category..."
                className="w-full pl-8 pr-3 py-2 rounded-xl bg-[#090D16] border border-blue-500/15 text-xs text-white placeholder-zinc-500 outline-none"
              />
            </div>

            {/* Video List (Matching Screenshot 3) */}
            <div className="space-y-2">
              {filteredVideos.map((video) => (
                <div
                  key={video.id}
                  className="p-3 rounded-2xl bg-[#090D16] border border-zinc-800/80 hover:border-blue-500/30 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative w-16 h-10 rounded-lg overflow-hidden bg-black shrink-0 border border-zinc-800">
                      <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover" />
                      <span className="absolute bottom-0.5 right-0.5 px-1 rounded text-[8px] font-mono bg-black/80 text-white">
                        {video.duration || '16:9'}
                      </span>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-white truncate max-w-sm">{video.title}</span>
                        <span className="text-[9px] uppercase font-extrabold px-1.5 py-0.2 rounded bg-blue-950 text-cyan-300 border border-blue-800/50">
                          {video.categoryName}
                        </span>
                        {video.folderName && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-300">
                            📁 {video.folderName}
                          </span>
                        )}
                        {video.isFreePreview && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 font-bold">
                            FREE PREVIEW
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-zinc-500 block mt-0.5 font-mono">
                        {video.episode} • Added {new Date(video.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  {/* Actions & Published Toggle (Matching Screenshot 3) */}
                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                    <button
                      type="button"
                      disabled={operatingIds[video.id]}
                      onClick={() => handleToggleVideo(video)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        video.isPublished
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${video.isPublished ? 'bg-emerald-400' : 'bg-zinc-500'}`} />
                      <span>{video.isPublished ? 'Published' : 'Draft'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setEditingVideo(video)}
                      className="p-1.5 rounded-lg text-zinc-400 hover:text-white bg-zinc-800/60 hover:bg-zinc-800 cursor-pointer"
                      title="Edit Video"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Delete video "${video.title}"?`)) deleteVideo(video.id);
                      }}
                      className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 bg-zinc-800/60 hover:bg-zinc-800 cursor-pointer"
                      title="Delete Video"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: PDF PUBLICATIONS                                  */}
        {/* ======================================================== */}
        {activeTab === 'pdfs' && canManagePdfs && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white">PDF Publications & Study Guides</h2>
                <p className="text-xs text-zinc-400">Manage downloadable notes, formulas, and presets.</p>
              </div>

              <button
                type="button"
                onClick={() => setEditingPdf({
                  categoryId: categories[0]?.id || '',
                  categoryName: categories[0]?.name || '',
                  isPublished: true,
                  pageCount: 10
                })}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Upload PDF Guide</span>
              </button>
            </div>

            <div className="space-y-2">
              {filteredPdfs.map((pdf) => (
                <div
                  key={pdf.id}
                  className="p-3 rounded-2xl bg-[#090D16] border border-zinc-800/80 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-red-500/10 text-red-400 flex items-center justify-center shrink-0">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">{pdf.title}</span>
                      <span className="text-[10px] text-zinc-400 font-mono">
                        {pdf.categoryName} • {pdf.pageCount} Pages • {pdf.fileSize}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => togglePdfPublish(pdf.id, !pdf.isPublished)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        pdf.isPublished ? 'bg-emerald-950 text-emerald-400' : 'bg-zinc-800 text-zinc-500'
                      }`}
                    >
                      {pdf.isPublished ? 'Published' : 'Hidden'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingPdf(pdf)}
                      className="p-1 rounded text-zinc-400 hover:text-white"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Delete PDF "${pdf.title}"?`)) deletePdf(pdf.id);
                      }}
                      className="p-1 rounded text-zinc-400 hover:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 5: COURSE SUITES / CATEGORIES                        */}
        {/* ======================================================== */}
        {activeTab === 'categories' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white">Course Suites & Categories</h2>
                <p className="text-xs text-zinc-400">Manage master suites (Alight Motion, CapCut, Premiere, After Effects).</p>
              </div>

              <button
                type="button"
                onClick={() => setEditingCategory({ isActive: true, price: 299 })}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Create Course Suite</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {categories.map((cat) => (
                <div key={cat.id} className="p-4 rounded-2xl bg-[#090D16] border border-blue-500/20 flex flex-col justify-between">
                  <div className="flex items-start gap-3">
                    <img src={cat.thumbnailUrl} alt={cat.name} className="w-12 h-12 rounded-xl object-cover" />
                    <div>
                      <h4 className="font-bold text-white text-sm">{cat.name}</h4>
                      <p className="text-[11px] text-zinc-400 line-clamp-2 mt-0.5">{cat.description}</p>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-amber-400">Pass: ₹{cat.price}</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => toggleCategoryStatus(cat.id, !cat.isActive)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          cat.isActive ? 'bg-emerald-950 text-emerald-400' : 'bg-zinc-800 text-zinc-500'
                        }`}
                      >
                        {cat.isActive ? 'Active' : 'Disabled'}
                      </button>
                      <button onClick={() => setEditingCategory(cat)} className="p-1 rounded text-zinc-400 hover:text-white">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 6: STUDENT ACCESS MANAGEMENT (Screenshot 1)          */}
        {/* ======================================================== */}
        {activeTab === 'users' && canManageStudents && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white">Student & Access Management</h2>
                <p className="text-xs text-zinc-400">Unlock categories, assign all-access passes, and manage students.</p>
              </div>
            </div>

            {/* Filter pills & search */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-500" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={e => setUserSearch(e.target.value)}
                  placeholder="Search students by email or name..."
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-[#090D16] border border-blue-500/15 text-xs text-white placeholder-zinc-500 outline-none"
                />
              </div>
            </div>

            {/* Students List */}
            <div className="space-y-3">
              {filteredUsers.map((user) => (
                <div
                  key={user.uid}
                  className="p-4 rounded-2xl bg-[#090D16] border border-blue-500/15 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-600/20 text-cyan-400 flex items-center justify-center font-bold text-xs">
                        {user.displayName?.[0] || 'U'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">{user.displayName}</span>
                          <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                            isProtectedOwner(user) 
                              ? 'bg-amber-400/20 text-amber-300' 
                              : user.role === 'master_admin' 
                                ? 'bg-cyan-500/20 text-cyan-300'
                                : user.role === 'admin'
                                  ? 'bg-purple-500/20 text-purple-300'
                                  : 'bg-zinc-800 text-zinc-400'
                          }`}>
                            {isProtectedOwner(user) ? 'OWNER' : (user.assignedRoleTitle || user.role.toUpperCase())}
                          </span>
                        </div>
                        <span className="text-[10px] text-zinc-400 font-mono">{user.email}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleToggleUserAllAccess(user)}
                        className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          user.hasAllAccess
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                        }`}
                      >
                        {user.hasAllAccess ? '✓ All-Access Enabled' : 'Unlock All-Access'}
                      </button>

                      {canManageAdmins && (
                        <button
                          type="button"
                          onClick={() => handleOpenRoleModal(user)}
                          className="px-2.5 py-1 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-cyan-300 border border-blue-500/30 text-xs font-bold cursor-pointer"
                        >
                          Role / Permissions
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Multi-Category Access Switcher (Matching Screenshot 1) */}
                  <div className="pt-2 border-t border-zinc-800/80">
                    <div className="flex items-center justify-between text-[11px] mb-2">
                      <span className="text-zinc-400 font-semibold">Category Specific Access:</span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setAllCategoriesAccess(user.uid, true)}
                          className="text-cyan-400 hover:underline cursor-pointer"
                        >
                          Turn ON All
                        </button>
                        <span className="text-zinc-600">•</span>
                        <button
                          type="button"
                          onClick={() => setAllCategoriesAccess(user.uid, false)}
                          className="text-zinc-500 hover:text-white cursor-pointer"
                        >
                          Turn OFF All
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {categories.map((cat) => {
                        const hasCat = user.hasAllAccess || user.allowedCategories?.includes(cat.id);
                        return (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={() => updateUserCategoryAccess(user.uid, cat.id, !hasCat)}
                            className={`p-1.5 rounded-lg text-[10px] font-bold flex items-center justify-between px-2 cursor-pointer ${
                              hasCat 
                                ? 'bg-emerald-950/70 border border-emerald-500/30 text-emerald-300' 
                                : 'bg-[#05070D] border border-zinc-800 text-zinc-500'
                            }`}
                          >
                            <span className="truncate">{cat.name}</span>
                            <span>{hasCat ? 'ON' : 'OFF'}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 7: ROLES & PERMISSIONS SECTION                       */}
        {/* ======================================================== */}
        {activeTab === 'roles' && canManageAdmins && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-amber-400" />
                  <span>Roles & Administrator Hierarchy</span>
                </h2>
                <p className="text-xs text-zinc-400">
                  Manage administrator authorities, assign predefined roles, and configure granular permissions.
                </p>
              </div>
            </div>

            {/* Protected Owner Banner */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-yellow-500/5 to-transparent border border-amber-500/30 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-black flex items-center justify-center font-bold">
                  <Crown className="w-5 h-5 fill-black" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">Protected Platform Owner</span>
                    <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded bg-amber-400 text-black">
                      PERMANENT
                    </span>
                  </div>
                  <span className="text-[11px] text-zinc-400 font-mono">{MASTER_ADMIN_EMAIL}</span>
                </div>
              </div>
              <span className="text-[11px] text-amber-300 font-semibold hidden sm:inline">
                Full Immutable System Authority
              </span>
            </div>

            {/* Administrator Management Table */}
            <div className="space-y-2.5">
              {users.filter(u => u.role !== 'user' || isProtectedOwner(u)).map((admin) => {
                const isTargetOwner = isProtectedOwner(admin);
                const isTargetMaster = admin.role === 'master_admin';

                return (
                  <div
                    key={admin.uid}
                    className="p-3.5 rounded-2xl bg-[#090D16] border border-blue-500/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                        {admin.displayName?.[0] || 'A'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">{admin.displayName}</span>
                          <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                            isTargetOwner
                              ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                              : isTargetMaster
                                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                                : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                          }`}>
                            {isTargetOwner ? 'OWNER' : (admin.assignedRoleTitle || admin.role.toUpperCase())}
                          </span>
                          {admin.isSuspended && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                              SUSPENDED
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-zinc-400 font-mono block mt-0.5">
                          {admin.email} • {admin.permissions?.length || 0} Permissions
                        </span>
                      </div>
                    </div>

                    {/* Admin Actions */}
                    {!isTargetOwner && (
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleOpenRoleModal(admin)}
                          className="px-2.5 py-1 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-cyan-300 border border-blue-500/30 text-xs font-bold cursor-pointer"
                        >
                          Edit Permissions
                        </button>

                        <button
                          type="button"
                          onClick={() => handleToggleSuspension(admin)}
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            admin.isSuspended
                              ? 'bg-emerald-950/70 border border-emerald-500/40 text-emerald-300'
                              : 'bg-rose-950/70 border border-rose-500/40 text-rose-300'
                          }`}
                        >
                          {admin.isSuspended ? 'Reactivate' : 'Suspend'}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveAdmin(admin)}
                          className="px-2.5 py-1 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold cursor-pointer"
                        >
                          Demote
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 8: SECURITY AUDIT LOGS                               */}
        {/* ======================================================== */}
        {activeTab === 'audit' && canViewAudit && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <History className="w-5 h-5 text-cyan-400" />
                  <span>Security Audit Logs</span>
                </h2>
                <p className="text-xs text-zinc-400">
                  Traceable history of administrative actions, permission appointments, and login events.
                </p>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-500" />
                <input
                  type="text"
                  value={auditSearch}
                  onChange={e => setAuditSearch(e.target.value)}
                  placeholder="Filter logs by actor, action..."
                  className="pl-8 pr-3 py-1.5 rounded-xl bg-[#090D16] border border-blue-500/15 text-xs text-white placeholder-zinc-500 outline-none"
                />
              </div>
            </div>

            <div className="rounded-2xl bg-[#090D16] border border-blue-500/15 overflow-hidden">
              <div className="divide-y divide-zinc-800/80">
                {filteredAuditLogs.length > 0 ? (
                  filteredAuditLogs.map((log) => (
                    <div key={log.id} className="p-3 text-xs flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-cyan-300 font-mono text-[11px]">{log.action}</span>
                          <span className="text-[10px] text-zinc-500">•</span>
                          <span className="text-zinc-300 font-semibold">{log.actorEmail}</span>
                          <span className="text-[9px] px-1 rounded bg-zinc-800 text-zinc-400 font-mono">{log.actorRole}</span>
                        </div>
                        <p className="text-zinc-400 text-[11px] leading-tight">{log.details}</p>
                      </div>
                      <span className="text-[10px] text-zinc-500 font-mono shrink-0">
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center text-zinc-500 text-xs">No audit logs recorded yet.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 9: PAYMENT PROOFS                                    */}
        {/* ======================================================== */}
        {activeTab === 'payments' && canVerifyPayments && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div>
              <h2 className="text-lg font-bold text-white">Payment Proof Submissions</h2>
              <p className="text-xs text-zinc-400">Verify user UPI payment screenshots and unlock courses.</p>
            </div>

            <div className="space-y-2.5">
              {paymentRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-3.5 rounded-2xl bg-[#090D16] border border-blue-500/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={req.proofUrl}
                      alt="Proof Thumbnail"
                      onClick={() => setViewingProof(req)}
                      className="w-14 h-14 rounded-xl object-cover border border-zinc-700 cursor-pointer hover:scale-105 transition-transform"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{req.userName}</span>
                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                          req.status === 'approved' 
                            ? 'bg-emerald-950 text-emerald-400' 
                            : req.status === 'rejected' 
                              ? 'bg-rose-950 text-rose-400' 
                              : 'bg-amber-950 text-amber-400 animate-pulse'
                        }`}>
                          {req.status.toUpperCase()}
                        </span>
                      </div>
                      <span className="text-[11px] text-zinc-400 font-mono block">
                        ₹{req.amount} • {req.planType === 'all_access' ? 'All-Access Pass' : req.categoryName}
                      </span>
                      <span className="text-[10px] text-zinc-500 font-mono block">
                        UTR: {req.utr} • {new Date(req.submittedAt).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => setViewingProof(req)}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
                    >
                      View Receipt
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 10: PAYMENT SETTINGS (GATEWAY)                       */}
        {/* ======================================================== */}
        {activeTab === 'payment-settings' && canManageSettings && (
          <form onSubmit={handleSaveSettings} className="max-w-md space-y-4 animate-in fade-in duration-150">
            <div>
              <h2 className="text-lg font-bold text-white">UPI Gateway & Platform Settings</h2>
              <p className="text-xs text-zinc-400">Configure recipient UPI details, payee branding, and pricing.</p>
            </div>

            <div className="p-4 rounded-2xl bg-[#090D16] border border-blue-500/20 space-y-3 text-xs">
              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Recipient UPI ID *</label>
                <input
                  type="text"
                  required
                  value={settingsForm.upiId}
                  onChange={e => setSettingsForm({ ...settingsForm, upiId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Payee Name *</label>
                <input
                  type="text"
                  required
                  value={settingsForm.payeeName}
                  onChange={e => setSettingsForm({ ...settingsForm, payeeName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">All-Access Pass Price (₹) *</label>
                <input
                  type="number"
                  required
                  min={99}
                  value={settingsForm.allAccessPrice}
                  onChange={e => setSettingsForm({ ...settingsForm, allAccessPrice: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white font-mono outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSavingSettings}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs shadow-md cursor-pointer"
              >
                {isSavingSettings ? 'Saving...' : 'Save Payment Gateway Settings'}
              </button>
            </div>
          </form>
        )}

        {/* ======================================================== */}
        {/* TAB 11: GENERAL SETTINGS & SOURCE EXPORT                 */}
        {/* ======================================================== */}
        {activeTab === 'general' && (
          <div className="max-w-lg space-y-4 animate-in fade-in duration-150">
            <div className="p-5 rounded-2xl bg-[#090D16] border border-blue-500/20 space-y-4">
              <h2 className="text-base font-bold text-white">Platform Actions & Utilities</h2>
              
              <div className="p-3.5 rounded-xl bg-[#05070D] border border-zinc-800 space-y-2">
                <span className="text-xs font-bold text-white block">Download Complete Project ZIP</span>
                <p className="text-[11px] text-zinc-400">
                  Export the full source code archive of Skill-Flix.
                </p>
                <a
                  href="/skill-flix-source.zip"
                  download="skill-flix-source.zip"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
                >
                  <span>Download skill-flix-source.zip</span>
                </a>
              </div>

              <div className="p-3.5 rounded-xl bg-[#05070D] border border-zinc-800 space-y-2">
                <span className="text-xs font-bold text-white block">Pre-seed Course & Folder Hierarchy</span>
                <p className="text-[11px] text-zinc-400">
                  Initialize Alight Motion, CapCut, Premiere Pro, and After Effects courses with structured subfolders and lessons.
                </p>
                <button
                  type="button"
                  onClick={onSeedDefaults}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-bold text-xs cursor-pointer"
                >
                  Initialize Suites & Folders Now
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ======================================================== */}
      {/* MODAL: EDIT / CREATE FOLDER                              */}
      {/* ======================================================== */}
      {editingFolder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-[#0B0F19] border border-blue-500/30 rounded-2xl p-5 text-white">
            <button onClick={() => setEditingFolder(null)} className="absolute top-3.5 right-3.5 p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
              <FolderPlus className="w-4 h-4 text-cyan-400" />
              <span>{editingFolder.id ? 'Edit Folder' : 'Create New Folder'}</span>
            </h3>

            <form onSubmit={handleSaveFolderSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Folder Name *</label>
                <input
                  type="text"
                  required
                  value={editingFolder.name || ''}
                  onChange={e => setEditingFolder({ ...editingFolder, name: e.target.value })}
                  placeholder="e.g. Beginner Course / Advanced Editing"
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Parent Suite / Category</label>
                <select
                  value={editingFolder.categoryId || ''}
                  onChange={e => {
                    const c = categories.find(cat => cat.id === e.target.value);
                    setEditingFolder({ 
                      ...editingFolder, 
                      categoryId: e.target.value, 
                      categoryName: c?.name || '',
                      parentId: editingFolder.parentId || e.target.value
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                >
                  <option value="">Select Root Category (Optional)</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Parent Subfolder (Optional)</label>
                <select
                  value={editingFolder.parentId || ''}
                  onChange={e => setEditingFolder({ ...editingFolder, parentId: e.target.value || null })}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                >
                  <option value="">None (Top Level in Category)</option>
                  {folders.filter(f => f.id !== editingFolder.id).map(f => (
                    <option key={f.id} value={f.id}>{f.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Description</label>
                <textarea
                  rows={2}
                  value={editingFolder.description || ''}
                  onChange={e => setEditingFolder({ ...editingFolder, description: e.target.value })}
                  placeholder="Brief summary of what this folder contains..."
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer shadow-md"
                >
                  Save Folder
                </button>
                <button
                  type="button"
                  onClick={() => setEditingFolder(null)}
                  className="px-4 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: CONFIRM DELETION WITH WARNING                     */}
      {/* ======================================================== */}
      {folderToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-[#0B0F19] border border-rose-500/40 rounded-2xl p-5 text-white shadow-2xl">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center mb-3">
              <AlertTriangle className="w-5 h-5" />
            </div>
            
            <h3 className="text-sm font-bold text-white mb-1">
              Delete Folder "{folderToDelete.name}"?
            </h3>

            <p className="text-xs text-zinc-300 mb-4 leading-relaxed">
              This folder currently contains subfolders and resources. Please choose how you want to handle the contents:
            </p>

            <div className="space-y-2 p-3 rounded-xl bg-[#05070D] border border-zinc-800 text-xs mb-4">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="radio"
                  name="deleteOption"
                  checked={deleteFolderContents}
                  onChange={() => setDeleteFolderContents(true)}
                  className="text-rose-600"
                />
                <span>Delete folder AND all contained subfolders & videos permanently</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="radio"
                  name="deleteOption"
                  checked={!deleteFolderContents}
                  onChange={() => setDeleteFolderContents(false)}
                  className="text-blue-600"
                />
                <span>Delete folder only, move contents up to parent directory</span>
              </label>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleConfirmDeleteFolder}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs cursor-pointer shadow-md"
              >
                Confirm Deletion
              </button>
              <button
                type="button"
                onClick={() => setFolderToDelete(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ASSIGN ROLES & PERMISSIONS                        */}
      {/* ======================================================== */}
      {selectedUserForRole && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-lg bg-[#0B0F19] border border-blue-500/30 rounded-2xl p-5 text-white my-6">
            <button onClick={() => setSelectedUserForRole(null)} className="absolute top-3.5 right-3.5 p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>

            <h3 className="font-bold text-sm mb-1 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Configure Administrator Permissions</span>
            </h3>
            <p className="text-xs text-zinc-400 mb-4 font-mono">
              Target: {selectedUserForRole.displayName} ({selectedUserForRole.email})
            </p>

            {/* Predefined Role Selector */}
            <div className="mb-4">
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Select Role Template</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-xs">
                {[
                  { id: 'video_manager', label: 'Video Manager' },
                  { id: 'finance_manager', label: 'Finance Manager' },
                  { id: 'student_support', label: 'Student Support' },
                  { id: 'admin', label: 'Full Admin' },
                  ...(isOwner ? [{ id: 'master_admin', label: 'Master Admin' }] : []),
                  { id: 'custom', label: 'Custom Perms' }
                ].map((role) => (
                  <button
                    key={role.id}
                    type="button"
                    onClick={() => {
                      const r = role.id as PredefinedRole;
                      setSelectedRoleType(r);
                      setCustomPermissions(getPermissionsForRole(r));
                    }}
                    className={`py-2 px-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                      selectedRoleType === role.id
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                        : 'bg-[#05070D] border border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {role.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Granular Checkboxes List */}
            <div className="space-y-3 mb-5 max-h-64 overflow-y-auto pr-1">
              {['Dashboard', 'Content Management', 'Media', 'Students & Access', 'Finance', 'Administration'].map((group) => {
                const groupPerms = SYSTEM_PERMISSIONS.filter(p => p.group === group);
                return (
                  <div key={group} className="p-2.5 rounded-xl bg-[#05070D] border border-zinc-800 space-y-1.5">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-cyan-400 block">
                      {group}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {groupPerms.map((perm) => {
                        const isChecked = customPermissions.includes(perm.key);
                        return (
                          <label key={perm.key} className="flex items-center gap-2 text-[11px] text-zinc-300 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                setSelectedRoleType('custom');
                                if (e.target.checked) {
                                  setCustomPermissions([...customPermissions, perm.key]);
                                } else {
                                  setCustomPermissions(customPermissions.filter(k => k !== perm.key));
                                }
                              }}
                              className="rounded border-zinc-700 text-blue-600"
                            />
                            <span className="truncate" title={perm.description}>{perm.label}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleSaveRoleAndPermissions}
                className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md cursor-pointer"
              >
                Save Role & Permissions
              </button>
              <button
                type="button"
                onClick={() => setSelectedUserForRole(null)}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: VIEW PROOF                                        */}
      {/* ======================================================== */}
      {viewingProof && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="relative w-full max-w-md bg-[#0B0F19] border border-blue-500/30 rounded-2xl p-4 text-white">
            <button onClick={() => setViewingProof(null)} className="absolute top-3.5 right-3.5 p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-bold text-sm mb-1">{viewingProof.userName} ({viewingProof.userEmail})</h3>
            <p className="text-xs text-cyan-300 font-mono mb-3">UTR: {viewingProof.utr} • ₹{viewingProof.amount}</p>
            <img src={viewingProof.proofUrl} alt="Receipt" className="max-h-80 w-full object-contain rounded-lg border border-zinc-800 mb-3 bg-black" />
            {viewingProof.status === 'pending' && (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleResolvePayment(viewingProof.id, 'approved')}
                  className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer shadow-md"
                >
                  Approve & Unlock
                </button>
                <button
                  type="button"
                  onClick={() => handleResolvePayment(viewingProof.id, 'rejected')}
                  className="flex-1 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-500/40 font-bold text-xs cursor-pointer"
                >
                  Reject
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: CREATE / EDIT VIDEO                               */}
      {/* ======================================================== */}
      {editingVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 overflow-y-auto">
          <div className="relative w-full max-w-md bg-[#0B0F19] border border-blue-500/30 rounded-2xl p-5 text-white my-6">
            <button onClick={() => setEditingVideo(null)} className="absolute top-3.5 right-3.5 p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-bold text-sm mb-3">
              {editingVideo.id ? 'Edit Video Lesson' : 'Upload Video Lesson'}
            </h3>

            <form onSubmit={handleSaveVideoSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Title *</label>
                <input
                  type="text"
                  required
                  value={editingVideo.title || ''}
                  onChange={e => setEditingVideo({ ...editingVideo, title: e.target.value })}
                  placeholder="e.g. Master Vector Curvature Handles"
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Course Suite / Category *</label>
                <select
                  required
                  value={editingVideo.categoryId || ''}
                  onChange={e => {
                    const c = categories.find(cat => cat.id === e.target.value);
                    setEditingVideo({ 
                      ...editingVideo, 
                      categoryId: e.target.value, 
                      categoryName: c?.name || '',
                      folderId: editingVideo.folderId || e.target.value
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                >
                  <option value="">Select Category</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Folder Destination</label>
                <select
                  value={editingVideo.folderId || ''}
                  onChange={e => {
                    const f = folders.find(fld => fld.id === e.target.value);
                    setEditingVideo({
                      ...editingVideo,
                      folderId: e.target.value,
                      folderName: f?.name || ''
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                >
                  <option value="">Category Root</option>
                  {folders.map(f => (
                    <option key={f.id} value={f.id}>📁 {f.name} ({f.categoryName || 'General'})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Video URL (YouTube embed or MP4) *</label>
                <input
                  type="url"
                  required
                  value={editingVideo.videoUrl || ''}
                  onChange={e => setEditingVideo({ ...editingVideo, videoUrl: e.target.value })}
                  placeholder="https://www.youtube.com/watch?v=..."
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-zinc-300 mb-1 font-semibold">Episode Tag</label>
                  <input
                    type="text"
                    value={editingVideo.episode || 'EP1'}
                    onChange={e => setEditingVideo({ ...editingVideo, episode: e.target.value })}
                    placeholder="EP1"
                    className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-zinc-300 mb-1 font-semibold">Duration</label>
                  <input
                    type="text"
                    value={editingVideo.duration || '15:00'}
                    onChange={e => setEditingVideo({ ...editingVideo, duration: e.target.value })}
                    placeholder="15:00"
                    className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Thumbnail URL</label>
                <input
                  type="url"
                  value={editingVideo.thumbnailUrl || ''}
                  onChange={e => setEditingVideo({ ...editingVideo, thumbnailUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                />
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingVideo.isFreePreview || false}
                    onChange={e => setEditingVideo({ ...editingVideo, isFreePreview: e.target.checked })}
                    className="rounded border-zinc-700 text-blue-600"
                  />
                  <span>Free Preview</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingVideo.isPublished ?? true}
                    onChange={e => setEditingVideo({ ...editingVideo, isPublished: e.target.checked })}
                    className="rounded border-zinc-700 text-blue-600"
                  />
                  <span>Published Immediately</span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md cursor-pointer mt-2"
              >
                Save Video Lesson
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: CREATE / EDIT PDF                                 */}
      {/* ======================================================== */}
      {editingPdf && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="relative w-full max-w-sm bg-[#0B0F19] border border-blue-500/30 rounded-2xl p-5 text-white">
            <button onClick={() => setEditingPdf(null)} className="absolute top-3.5 right-3.5 p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-bold text-sm mb-3">Upload PDF Resource</h3>
            <form onSubmit={handleSavePdfSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Title *</label>
                <input
                  type="text"
                  required
                  value={editingPdf.title || ''}
                  onChange={e => setEditingPdf({ ...editingPdf, title: e.target.value })}
                  placeholder="e.g. Speed Curves Formula Guide"
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Category *</label>
                <select
                  required
                  value={editingPdf.categoryId || ''}
                  onChange={e => {
                    const c = categories.find(cat => cat.id === e.target.value);
                    setEditingPdf({ ...editingPdf, categoryId: e.target.value, categoryName: c?.name || '' });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                >
                  <option value="">Select Category</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">PDF Document URL *</label>
                <input
                  type="url"
                  required
                  value={editingPdf.pdfUrl || ''}
                  onChange={e => setEditingPdf({ ...editingPdf, pdfUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md cursor-pointer mt-2"
              >
                Save PDF Guide
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: CREATE / EDIT CATEGORY                            */}
      {/* ======================================================== */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
          <div className="relative w-full max-w-sm bg-[#0B0F19] border border-blue-500/30 rounded-2xl p-5 text-white">
            <button onClick={() => setEditingCategory(null)} className="absolute top-3.5 right-3.5 p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-bold text-sm mb-3">Course Suite Details</h3>
            <form onSubmit={async (e) => {
              e.preventDefault();
              if (!editingCategory.name) return;
              await saveCategory(editingCategory as any);
              showToast('Course suite updated!', 'success');
              setEditingCategory(null);
            }} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Suite Name *</label>
                <input
                  type="text"
                  required
                  value={editingCategory.name || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-semibold">Pass Price (₹)</label>
                <input
                  type="number"
                  min={49}
                  value={editingCategory.price || 299}
                  onChange={e => setEditingCategory({ ...editingCategory, price: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-[#05070D] border border-blue-500/25 text-white font-mono outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md cursor-pointer mt-2"
              >
                Save Course Suite
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
