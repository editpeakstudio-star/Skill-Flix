import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Play, 
  FileText, 
  Lock, 
  CheckCircle, 
  Clock, 
  Crown, 
  Download, 
  Sparkles,
  ExternalLink,
  Folder as FolderIcon,
  ChevronRight,
  FolderOpen
} from 'lucide-react';
import { Category, Folder, VideoLesson, PdfResource, UserProfile } from '../types';

interface CategoryDetailViewProps {
  category: Category;
  folders: Folder[];
  videos: VideoLesson[];
  pdfs: PdfResource[];
  currentUser: UserProfile | null;
  onBack: () => void;
  onPlayVideo: (video: VideoLesson) => void;
  onViewPdf: (pdf: PdfResource) => void;
  onOpenSubscribe: (cat?: Category) => void;
}

export const CategoryDetailView: React.FC<CategoryDetailViewProps> = ({
  category,
  folders,
  videos,
  pdfs,
  currentUser,
  onBack,
  onPlayVideo,
  onViewPdf,
  onOpenSubscribe
}) => {
  const [activeTab, setActiveTab] = useState<'videos' | 'pdfs'>('videos');
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);

  const isAdmin = currentUser?.role === 'master_admin' || currentUser?.role === 'admin';
  const hasAllAccess = currentUser?.hasAllAccess;
  const isCategoryUnlocked = hasAllAccess || isAdmin || (currentUser?.allowedCategories?.includes(category.id));

  // Determine current active folder object if nested
  const currentFolder = currentFolderId ? folders.find(f => f.id === currentFolderId) || null : null;

  // Build breadcrumb trail
  const getBreadcrumbs = () => {
    const crumbs: { id: string | null; name: string }[] = [{ id: null, name: category.name }];
    let pointer = currentFolder;
    const path: { id: string; name: string }[] = [];
    while (pointer) {
      path.unshift({ id: pointer.id, name: pointer.name });
      pointer = pointer.parentId && pointer.parentId !== category.id 
        ? folders.find(f => f.id === pointer!.parentId) || null 
        : null;
    }
    return [...crumbs, ...path];
  };

  const breadcrumbs = getBreadcrumbs();

  // Subfolders under current folder
  const currentSubfolders = folders.filter(f => {
    if (f.categoryId !== category.id && f.parentId !== category.id) return false;
    if (currentFolderId === null) {
      return f.parentId === null || f.parentId === category.id;
    }
    return f.parentId === currentFolderId;
  }).sort((a, b) => (a.order || 0) - (b.order || 0));

  // Videos under current folder (or category root)
  const currentVideos = videos.filter(v => {
    if (v.categoryId !== category.id) return false;
    if (!isAdmin && !v.isPublished) return false;
    if (currentFolderId === null) {
      // If at root, include videos with folderId matching categoryId, null, or no subfolder
      return !v.folderId || v.folderId === category.id || currentSubfolders.length === 0;
    }
    return v.folderId === currentFolderId;
  }).sort((a, b) => (a.order || 0) - (b.order || 0));

  // PDFs under current folder
  const currentPdfs = pdfs.filter(p => {
    if (p.categoryId !== category.id) return false;
    if (!isAdmin && !p.isPublished) return false;
    if (currentFolderId === null) {
      return !p.folderId || p.folderId === category.id || currentSubfolders.length === 0;
    }
    return p.folderId === currentFolderId;
  }).sort((a, b) => (a.order || 0) - (b.order || 0));

  // Total counts for header
  const totalCategoryVideos = videos.filter(v => v.categoryId === category.id && (isAdmin || v.isPublished)).length;
  const totalCategoryPdfs = pdfs.filter(p => p.categoryId === category.id && (isAdmin || p.isPublished)).length;

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-150">
      
      {/* Back button & Breadcrumb bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Category Collections</span>
        </button>

        {/* Dynamic Breadcrumbs */}
        <div className="flex items-center gap-1.5 text-xs text-slate-400 overflow-x-auto py-1 scrollbar-none">
          <span className="text-slate-500">Skill-Flix</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-600 shrink-0" />
          {breadcrumbs.map((crumb, idx) => {
            const isLast = idx === breadcrumbs.length - 1;
            return (
              <React.Fragment key={crumb.id || 'root'}>
                {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-slate-600 shrink-0" />}
                <button
                  type="button"
                  onClick={() => setCurrentFolderId(crumb.id)}
                  className={`cursor-pointer whitespace-nowrap transition-colors ${
                    isLast 
                      ? 'text-cyan-400 font-bold' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {crumb.name}
                </button>
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Category Hero Header Banner */}
      <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden bg-[#090D18] border border-blue-500/20 p-5 sm:p-7 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-slate-800 shrink-0 border border-white/[0.1] shadow-lg">
              <img
                src={category.thumbnailUrl}
                alt={category.name}
                className="w-full h-full object-cover"
              />
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                  {currentFolder ? currentFolder.name : category.name}
                </h1>
                {isCategoryUnlocked ? (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Unlocked
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Premium
                  </span>
                )}
              </div>

              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                {currentFolder?.description || category.description || `Complete masterclass series and editing material library for ${category.name}.`}
              </p>

              <div className="flex items-center gap-3 text-xs text-slate-400 mt-2 font-medium">
                <span>{totalCategoryVideos} Video Lessons</span>
                <span>•</span>
                <span>{totalCategoryPdfs} PDF Guides</span>
                {folders.filter(f => f.categoryId === category.id).length > 0 && (
                  <>
                    <span>•</span>
                    <span>{folders.filter(f => f.categoryId === category.id).length} Subfolders</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Action button if locked */}
          {!isCategoryUnlocked && (
            <div className="flex flex-wrap sm:flex-col gap-2 shrink-0 w-full sm:w-auto">
              <button
                onClick={() => onOpenSubscribe(category)}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
              >
                <Lock className="w-4 h-4" />
                <span>Unlock Category (₹{category.price || 299})</span>
              </button>

              <button
                onClick={() => onOpenSubscribe()}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold transition-all cursor-pointer"
              >
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>All-Access Pass (₹999)</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Subfolders Grid Section (if any subfolders exist in current view) */}
      {currentSubfolders.length > 0 && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between px-0.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <FolderIcon className="w-3.5 h-3.5 text-cyan-400" />
              <span>Subfolders & Course Modules ({currentSubfolders.length})</span>
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
            {currentSubfolders.map((folder) => {
              const fVideosCount = videos.filter(v => v.folderId === folder.id && (isAdmin || v.isPublished)).length;
              const fPdfsCount = pdfs.filter(p => p.folderId === folder.id && (isAdmin || p.isPublished)).length;

              return (
                <div
                  key={folder.id}
                  onClick={() => setCurrentFolderId(folder.id)}
                  className="group p-3 rounded-2xl bg-[#090D18] hover:bg-[#0D1424] border border-blue-500/20 hover:border-cyan-400/50 shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between"
                >
                  <div className="flex items-start gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600/20 to-cyan-500/20 border border-blue-500/30 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform">
                      <FolderOpen className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors truncate">
                        {folder.name}
                      </h4>
                      <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                        {folder.description || 'Module tutorials & resources'}
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-white/[0.06] flex items-center justify-between text-[10px] text-slate-400">
                    <span>{fVideosCount} Videos • {fPdfsCount} PDFs</span>
                    <span className="text-cyan-400 font-semibold group-hover:translate-x-0.5 transition-transform">
                      Open →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Content Tabs (Videos vs PDFs) */}
      <div className="flex items-center gap-3 border-b border-white/[0.08] pb-1">
        <button
          onClick={() => setActiveTab('videos')}
          className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'videos'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Play className="w-4 h-4" />
          <span>Video Lessons ({currentVideos.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('pdfs')}
          className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'pdfs'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>PDF & Materials ({currentPdfs.length})</span>
        </button>
      </div>

      {/* Tab Content: Video Lessons */}
      {activeTab === 'videos' && (
        <div>
          {currentVideos.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {currentVideos.map((video) => {
                const canWatch = isCategoryUnlocked || video.isFreePreview;

                return (
                  <div
                    key={video.id}
                    onClick={() => {
                      if (canWatch) {
                        onPlayVideo(video);
                      } else {
                        onOpenSubscribe(category);
                      }
                    }}
                    className="group rounded-2xl bg-[#090D18] border border-white/[0.08] hover:border-blue-500/40 overflow-hidden shadow-lg transition-all duration-200 cursor-pointer flex flex-col justify-between"
                  >
                    <div className="relative aspect-video w-full bg-slate-900 overflow-hidden">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

                      {/* Episode tag */}
                      <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-blue-600/90 text-white shadow">
                        {video.episode || 'EP1'}
                      </span>

                      {/* Duration */}
                      <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-black/80 text-slate-200 backdrop-blur-sm">
                        {video.duration || '15:00'}
                      </span>

                      {/* Free Preview badge */}
                      {video.isFreePreview && (
                        <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-emerald-500/80 text-white shadow">
                          Free Preview
                        </span>
                      )}

                      {/* Lock overlay if locked */}
                      {!canWatch && (
                        <div className="absolute inset-0 bg-black/65 backdrop-blur-[1px] flex flex-col items-center justify-center p-3 text-center">
                          <div className="w-9 h-9 rounded-full bg-black/80 border border-amber-500/40 text-amber-400 flex items-center justify-center mb-1">
                            <Lock className="w-4 h-4" />
                          </div>
                          <span className="text-[11px] font-bold text-amber-300">
                            Locked • Tap to Unlock
                          </span>
                        </div>
                      )}

                      {/* Play hover */}
                      {canWatch && (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                          <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg">
                            <Play className="w-5 h-5 fill-white ml-0.5" />
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="p-3.5 flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-blue-400 transition-colors line-clamp-2">
                          {video.title}
                        </h4>
                        <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                          {video.description}
                        </p>
                      </div>

                      <div className="mt-3 pt-2 border-t border-white/[0.06] flex items-center justify-between text-[11px]">
                        <span className="text-slate-500 truncate max-w-[140px]">
                          {video.folderName || video.categoryName}
                        </span>
                        <span className="text-blue-400 font-semibold flex items-center gap-1">
                          {canWatch ? 'Watch Lesson' : 'Unlock Access'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-[#090D18] border border-white/[0.08] text-center max-w-md mx-auto">
              <Play className="w-9 h-9 text-slate-600 mx-auto mb-2" />
              <h4 className="text-sm font-bold text-white">No video lessons in this folder</h4>
              <p className="text-xs text-slate-400 mt-1">
                Lessons can be added directly or organized into subfolders via Admin Console.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Tab Content: PDF Materials */}
      {activeTab === 'pdfs' && (
        <div>
          {currentPdfs.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {currentPdfs.map((pdf) => (
                <div
                  key={pdf.id}
                  onClick={() => onViewPdf(pdf)}
                  className="rounded-2xl bg-[#090D18] border border-white/[0.08] hover:border-blue-500/40 p-4 shadow-lg transition-all cursor-pointer flex flex-col justify-between group"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                        {pdf.title}
                      </h4>
                      <p className="text-[11px] text-slate-400 line-clamp-2 mt-0.5">
                        {pdf.description || 'Comprehensive notes and workflow blueprints.'}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/[0.06] flex items-center justify-between text-xs">
                    <span className="text-slate-400 text-[11px]">
                      {pdf.pageCount} Pages • {pdf.fileSize || 'PDF'}
                    </span>
                    <span className="text-blue-400 font-bold flex items-center gap-1">
                      {isCategoryUnlocked ? 'Open PDF' : '🔒 Locked'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-[#090D18] border border-white/[0.08] text-center max-w-md mx-auto">
              <FileText className="w-9 h-9 text-slate-600 mx-auto mb-2" />
              <h4 className="text-sm font-bold text-white">No PDF resources in this folder</h4>
              <p className="text-xs text-slate-400 mt-1">
                Course notes and presets can be uploaded via Admin Console.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
