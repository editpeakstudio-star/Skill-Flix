import { saveCategory, saveFolder, saveVideo, savePdf } from './firebase';

export async function seedEditingSuites(): Promise<void> {
  // 1. Alight Motion Category
  const alightMotion = await saveCategory({
    name: 'Alight Motion',
    slug: 'alight-motion',
    thumbnailUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=800&q=80',
    description: 'Master vector drawing, null objects, 3D camera tracking, and speed graph keyframes on mobile.',
    price: 299,
    isActive: true
  });

  // Alight Motion Subfolders
  const amBeginner = await saveFolder({
    name: 'Beginner Course',
    categoryId: alightMotion.id,
    categoryName: alightMotion.name,
    parentId: alightMotion.id,
    description: 'Foundational mobile motion design and layout mechanics.'
  });

  const amAdvanced = await saveFolder({
    name: 'Advanced Editing',
    categoryId: alightMotion.id,
    categoryName: alightMotion.name,
    parentId: alightMotion.id,
    description: 'Complex 3D parallax spaces, null hierarchies, and custom easing curves.'
  });

  // 2. CapCut Category
  const capcut = await saveCategory({
    name: 'CapCut',
    slug: 'capcut',
    thumbnailUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=800&q=80',
    description: 'Create viral TikTok & Reels edits with velocity curves, 3D zoom, and dynamic keyframe effects.',
    price: 299,
    isActive: true
  });

  // CapCut Subfolders
  const capReels = await saveFolder({
    name: 'Reels Editing',
    categoryId: capcut.id,
    categoryName: capcut.name,
    parentId: capcut.id,
    description: 'Short-form pacing, dynamic hooks, and trending speed transitions.'
  });

  const capEffects = await saveFolder({
    name: 'Effects Tutorial',
    categoryId: capcut.id,
    categoryName: capcut.name,
    parentId: capcut.id,
    description: 'Optical flow, blur flashes, glow overlays, and color LUTs.'
  });

  // 3. Premiere Pro Category
  const premiere = await saveCategory({
    name: 'Premiere Pro',
    slug: 'premiere-pro',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
    description: 'Industry-standard timeline pacing, cinematic Lumetri color grading, and multi-track audio engineering.',
    price: 399,
    isActive: true
  });

  const premTimeline = await saveFolder({
    name: 'Timeline & Pacing',
    categoryId: premiere.id,
    categoryName: premiere.name,
    parentId: premiere.id,
    description: 'Keyboard shortcuts, ripple editing, and rough cut assemblies.'
  });

  // 4. After Effects Category
  const afterEffects = await saveCategory({
    name: 'After Effects',
    slug: 'after-effects',
    thumbnailUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
    description: 'Advanced visual effects (VFX), rotoscoping, particle simulations, and motion graphic typography.',
    price: 499,
    isActive: true
  });

  const aeVfx = await saveFolder({
    name: 'VFX & Motion Graphics',
    categoryId: afterEffects.id,
    categoryName: afterEffects.name,
    parentId: afterEffects.id,
    description: 'Mocha tracking, glow plugins, expression rigging, and displacement maps.'
  });

  // Videos under Alight Motion -> Beginner Course
  await saveVideo({
    title: 'Master Vector Drawing & Custom Shapes',
    description: 'Learn vector anchor manipulation, bezier curvature handles, and line drawing animations in Alight Motion.',
    categoryId: alightMotion.id,
    categoryName: alightMotion.name,
    folderId: amBeginner.id,
    folderName: amBeginner.name,
    episode: 'EP1',
    videoUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
    duration: '16:40',
    isPublished: true,
    isFreePreview: true,
    order: 1
  });

  await saveVideo({
    title: 'Alight Motion Null Object & Multi-Layer Rigs',
    description: 'Connect complex element hierarchies using parent null layers and linked rotation trackers.',
    categoryId: alightMotion.id,
    categoryName: alightMotion.name,
    folderId: amBeginner.id,
    folderName: amBeginner.name,
    episode: 'EP2',
    videoUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80',
    duration: '14:22',
    isPublished: true,
    isFreePreview: false,
    order: 2
  });

  // Videos under Alight Motion -> Advanced Editing
  await saveVideo({
    title: '3D Camera Orbit & Perspective Scene Building',
    description: 'Build immersive 3D parallax spaces and navigate floating layer cards with custom focal lengths.',
    categoryId: alightMotion.id,
    categoryName: alightMotion.name,
    folderId: amAdvanced.id,
    folderName: amAdvanced.name,
    episode: 'EP1',
    videoUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=600&q=80',
    duration: '21:15',
    isPublished: true,
    isFreePreview: false,
    order: 1
  });

  // Videos under CapCut -> Reels Editing
  await saveVideo({
    title: 'Velocity Curves & Smooth Slow-Mo Masterclass',
    description: 'Configure optical flow re-timing and bezier velocity graphs for hyper-smooth beat sync drops.',
    categoryId: capcut.id,
    categoryName: capcut.name,
    folderId: capReels.id,
    folderName: capReels.name,
    episode: 'EP1',
    videoUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=600&q=80',
    duration: '12:30',
    isPublished: true,
    isFreePreview: true,
    order: 1
  });

  // Videos under CapCut -> Effects Tutorial
  await saveVideo({
    title: 'Dynamic Seamless Zoom & Flash Transition Kit',
    description: 'Combine edge glow, chromatic aberration, and directional blur into clean swipe transitions.',
    categoryId: capcut.id,
    categoryName: capcut.name,
    folderId: capEffects.id,
    folderName: capEffects.name,
    episode: 'EP1',
    videoUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=600&q=80',
    duration: '15:10',
    isPublished: true,
    isFreePreview: false,
    order: 1
  });

  // Premiere Pro Video
  await saveVideo({
    title: 'Cinematic Lumetri Color Grading Blueprint',
    description: 'Log curve normalization, teal & orange color splits, and skin tone vector scope isolation.',
    categoryId: premiere.id,
    categoryName: premiere.name,
    folderId: premTimeline.id,
    folderName: premTimeline.name,
    episode: 'EP1',
    videoUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80',
    duration: '28:50',
    isPublished: true,
    isFreePreview: false,
    order: 1
  });

  // After Effects Video
  await saveVideo({
    title: 'Saber Plugin Motion Trails & Sci-Fi VFX',
    description: 'Core energy animations, customized distortion masks, and composite glow falloffs.',
    categoryId: afterEffects.id,
    categoryName: afterEffects.name,
    folderId: aeVfx.id,
    folderName: aeVfx.name,
    episode: 'EP1',
    videoUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80',
    duration: '34:20',
    isPublished: true,
    isFreePreview: false,
    order: 1
  });

  // Sample PDF Guides with folder affiliations
  await savePdf({
    title: 'Alight Motion Vector Keyframe Cheatsheet',
    description: 'Quick reference formulas for graph curve acceleration and bezier anchor positioning.',
    categoryId: alightMotion.id,
    categoryName: alightMotion.name,
    folderId: amBeginner.id,
    folderName: amBeginner.name,
    pageCount: 14,
    fileSize: '4.2 MB',
    pdfUrl: 'https://raw.githubusercontent.com/mozilla/pdf.js/ba2edeae/web/compressed.tracemonkey-pldi-09.pdf',
    isPublished: true,
    order: 1
  });

  await savePdf({
    title: 'CapCut Viral Velocity Curves Guide',
    description: 'Optimal millisecond markers and speed ratios for Instagram Reels and YouTube Shorts algorithms.',
    categoryId: capcut.id,
    categoryName: capcut.name,
    folderId: capReels.id,
    folderName: capReels.name,
    pageCount: 8,
    fileSize: '2.8 MB',
    pdfUrl: 'https://raw.githubusercontent.com/mozilla/pdf.js/ba2edeae/web/compressed.tracemonkey-pldi-09.pdf',
    isPublished: true,
    order: 1
  });
}
